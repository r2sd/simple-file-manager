class Node:
	nodes = 0
	def __init__(self, data, left=None, right=None):
		self.data = data
		self.left = left
		self.right = right
		Node.nodes += 1

DEPTH = 0

def max_depth(root, depth):
	global DEPTH
	if root:
		depth += 1
		if depth > DEPTH:
			DEPTH = depth
		max_depth(root.left, depth)
		max_depth(root.right, depth)

def get_max_depth(root):
	global DEPTH
	DEPTH = 0
	max_depth(root, 0)
	print 'Max depth : ' + str(DEPTH)

def inorder(root):
	if root:
		inorder(root.left)
		print root.data
		inorder(root.right)

widths = []
def get_width(root, depth):
	global widths
	if root:
		depth += 1
		if len(widths) <= depth:
			widths.append(1)
		else:
			widths[depth] += 1
		get_width(root.left, depth)
		get_width(root.right, depth)
		

root = Node(1)
root.left = Node(1)
root.left.left = Node(1)
root.left.right = Node(1)
root.left.left.left = Node(1)
root.left.left.right = Node(1)
root.right = Node(1)
root.right.left = Node(1)
root.right.right = Node(1)
# inorder(root)
get_max_depth(root)
print 'Total number of nodes : ' + str(Node.nodes)
get_width(root, 0)
print 'Width of tree : ' + str(max(widths))
