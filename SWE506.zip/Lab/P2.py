with open('test.c', 'r') as f:
	lines = f.readlines()
	filtered_lines = []
	for line in lines:
		if line == '' or line[:2] == '//' or line == '\n':
			pass
		else:
			filtered_lines.append(line)
	print ''
	print 'SLOC (Lines of code excluding comments and empty lines) : ' + str(len(filtered_lines))
	print ''
	print 'KLOC (Lines of code with comments and empty lines) : ' + str(float(len(lines)) / 1000)
	print ''

with open('test.c', 'r') as f:
	contents = f.read()
	token_distinguish = ['\n','\t',' ',',','[',']','+','-','*','/','<','>','=']
	tokens = []
	token = ''
	for char in contents:
		if char in token_distinguish:
			if token:
				if ';' in token:
					tokens.append(token[:-1])
					tokens.append(';')
				else:
					tokens.append(token)
			token = ''
		else:
			token += char
	print 'Tokens are :'
	print tokens
	print ''
	
	data_types = ['int','float']
	variables = []
	inside_decl = False
	decl_terminators = [')', ';']
	variable_dict = {}
	for token in tokens:
		if token in data_types:
			inside_decl = True
		elif token in decl_terminators:
			inside_decl = False
		if inside_decl and token not in data_types:
			variables.append(token)
		if token in variables:
			if variable_dict.has_key(token):
				variable_dict[token] += 1
			else:
				variable_dict[token] = 1
	print 'Variables are :'
	print variables
	print ''
	print 'Number of variables are :'
	print len(variables)
	print ''
	print 'Variable counts are :'
	print variable_dict
	print ''
