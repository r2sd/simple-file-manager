import math
from collections import defaultdict
def log2(n):
	return math.log10(n) / 0.3010
with open('test.c', 'r') as f:
	contents = f.read()
	token_distinguish = ['\n','\t',' ',',','[',']','+','-','*','/','<','>','=']
	operators = ['+','-','*','/','<','>','=']
	operators_dict = defaultdict(lambda : 0)
	tokens = []
	token = ''
	for char in contents:
		if char in token_distinguish:
			if char in operators:
				operators_dict[char] += 1
			if token:
				if ';' in token:
					tokens.append(token[:-1])
					tokens.append(';')
				else:
					tokens.append(token)
			token = ''
		else:
			token += char
	print 'Tokens are :'
	print tokens
	print ''
	
	data_types = ['int','float']
	variables = []
	inside_decl = False
	decl_terminators = [')', ';']
	variable_dict = {}
	for token in tokens:
		if token in data_types:
			inside_decl = True
		elif token in decl_terminators:
			inside_decl = False
		if inside_decl and token not in data_types:
			variables.append(token)
		if token in variables:
			if variable_dict.has_key(token):
				variable_dict[token] += 1
			else:
				variable_dict[token] = 1
	print 'Variables are :'
	print variables
	print ''
	print 'Number of variables is :'
	n2 = len(variables)
	print n2
	print ''
	print 'Variable counts are :'
	print variable_dict
	N2 = 0
	for key, value in variable_dict.items():
		N2 += value
	print ''
	print 'Operator are :'
	print operators_dict.keys()
	print ''
	print 'Number of operators is :'
	n1 = len(operators_dict.keys())
	print n1
	print ''
	print 'Operator counts are :'
	print operators_dict.items()
	N1 = 0
	for key, value in operators_dict.items():
		N1 += value
	print ''
	
	n1 = float(n1)
	n2 = float(n2)
	N1 = float(N1)
	N2 = float(N2)
	print 'Halstead Metrics : '
	print 'Number of unique operators n1:'
	print n1
	print 'Number unique of operands n2:'
	print n2
	print 'Total number of operators N1:'
	print N1
	print 'Total number of operators N2:'
	print N2
	print 'Length N:'
	N = N1 + N2
	print N
	print 'Volume V:'
	n = n1 + n2
	V = N * log2(n)
	print V
	print 'Potential Volume V*:'
	V_p = (2 + n2) * log2(2 + n2)
	print V_p
	print 'Implementation Level L:'
	L = V_p / V
	print L
	print 'Difficulty D:'
	D = 1 / L
	print 'Program Level Estimator L\':'
	L_ = (2 / n1) * (n2 / N2)
	print L_
	print 'Intelligent Content I:'
	I = L_ / V
	print I
	print 'Programming Effort E:'
	E = V / L
	print E
	print 'Programming Time T:'
	S = 18
	T = E / S
	print T
