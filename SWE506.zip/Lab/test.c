int i, j, t;
if ( j < 2 ) 
	i = 2
